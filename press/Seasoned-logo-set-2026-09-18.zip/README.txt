Seasoned logo set, September 18, 2026

Files come in SVG (vector, any size) and PNG (transparent background, 2048 px wide).

seasoned-mark                  the coupe glass alone (brass glass, copper cherry). Works on light or dark.
seasoned-wordmark-on-light     "Seasoned." in Playfair Display Bold, dark ink, brass period. For light backgrounds.
seasoned-wordmark-on-dark      same, cream ink. For dark backgrounds.
seasoned-lockup-horizontal-*   mark beside wordmark, on-light and on-dark.
seasoned-lockup-stacked-*      mark above wordmark, centered, on-light and on-dark.
_preview-sheet.png             everything shown on its intended ground.

Colors
  Brass       #C8A24A   (glass, period)
  Copper      #B3673F   (cherry)
  Ink, light  #1E1A14   (wordmark on light)
  Ink, dark   #F3EAD9   (wordmark on dark)
  Deep green  #142922 at the top of the app screen, settling to #0F1D17
  Paper       #FAF7F0 (light mode ground), #FBF6EA (quiz card in dark mode)

Fonts: Playfair Display (headings, wordmark), Jost (everything else). Both are on Google Fonts.
Clear space: keep at least the height of the period around the lockup. Don't recolor the wordmark
outside the two inks; the mark stays brass and copper on both grounds.
