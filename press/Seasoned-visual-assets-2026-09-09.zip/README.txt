Seasoned visual assets, September 9, 2026
Demo restaurant: The Copper Fig (sample data, not a real customer)

screenshots/  28 PNGs, 1170 x 2532 (iPhone 3x), dark and light versions of each
  staff-home            the Tonight home screen (86 list, specials, assignments, training)
  staff-home-full       same screen, full page
  staff-lookup-oaky     Lookup tab with the "Oaky" chip active
  staff-lookup-card     the Chardonnay card opened from Lookup
  staff-progress        Progress tab, stars and best scores
  staff-quiz-question   a quiz question
  staff-quiz-verdict    the correct-answer state
  staff-level-complete  level complete with percentage and time
  staff-me              Me tab with the light/dark switch
  manager-tonight       manager's Tonight tab (board, 86 activity, who can 86)
  manager-players       assignments plus the player list
  manager-content       pack list
  manager-pack-editor   a pack in the editor (Make a Spanish copy button)
  manager-recent        recent sessions

clips/  MP4, 1080 wide, 30 fps, no audio
  clip-86-from-the-floor   a server 86s an item with the type-ahead (11 s)
  clip-lookup-oaky         "something oaky" on the Lookup tab (10 s)
  clip-quick-check         tonight's quick check, two questions (19 s)
  clip-light-dark          switching light and dark on the Me tab (9 s)
  clip-assignment          manager posts an assignment, staff sees it (21 s)
